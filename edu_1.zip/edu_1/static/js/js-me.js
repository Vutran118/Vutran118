

function getAllTodos(url) {
  fetch(url, {
    headers: {
      "X-Requested-With": "XMLHttpRequest",
    }
  })
  .then(response => response.json())
  .then(data => {
    const todoList = document.getElementById("t_body");
    todoList.innerHTML = "";
   
    (data.context).forEach(todo => {
      const todoHTMLElement = `
        <tr>
          <td> ${todo.idcd}</td>
          <td> ${todo.cauhoi}</td>
          <td> ${todo.ketqua}</td>
        </tr>`
        todoList.innerHTML += todoHTMLElement;
    });
  });
}

