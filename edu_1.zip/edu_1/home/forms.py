from django import forms
import re
from django.contrib.auth.models import User
from .models import qlnv, duongdan, detest


class registration_form(forms.Form):
    # Đăng ký thông tin user hệ thống
    username = forms.CharField(label="User Name:")
    #email= forms.CharField(label="email",widget=forms.EmailInput)
    password1 = forms.CharField(label="Mật khẩu:", widget= forms.PasswordInput)
    password2= forms.CharField(label="Nhập lại mật khẩu:", widget= forms.PasswordInput)
    # Đăng ký thông user hệ thống

    # Đang ký thông tin nhân viên vào bảng qlnv
    phongban=forms.CharField(label='Phòng ban:')
    idcd=forms.CharField(label='Mã công đoạn:')
    group_id=forms.IntegerField()
    
    # Đăng ký thông tin nhân viên
   

    def clean_password2(self):
        if 'password1' in self.cleaned_data:
            password1 = self.cleaned_data['password1']
            password2 = self.cleaned_data['password2']
            if password1 == password2 and password1:
                return password2
        raise forms.ValidationError("Mat khau khong hop le")

    def clean_username(self):
        username = self.cleaned_data['username']
        if not re.search(r'^\w+$',username):
            raise forms.ValidationError("Ten tai khoan co ky tu dac biet")
        try:
            User.objects.get(username=username)
        except User.DoesNotExist:
            return username
        raise forms.ValidationError ("Tai khoan da ton tai")
    
    def save(self):
        #ghi dữ liệu lên bản user tạo user mới
        User.objects.create_user(username=self.cleaned_data['username'],password= self.cleaned_data['password1'])
        
        #ghi dữ liệu lên bản dữ liệu 
        #qlnvs=qlnv.objects.all()
        qlnvs=qlnv (
            phongban=self.cleaned_data['phongban'],
            idcd=self.cleaned_data['idcd'],
            group_id=self.cleaned_data['group_id'],
            username=self.cleaned_data['username'],       
                  )
        qlnvs.save()

class form_dkdd(forms.Form):
    dd_database=forms.CharField(label="Database")
    dd_savedatapdf=forms.CharField(label="Save datapdf")

    def save(self):
        duongdan.objects.filter(add_name='Database').update(
            add_dd=self.cleaned_data['dd_database']
        )
        
        duongdan.objects.filter(add_name='Savedatapdf').update(
            add_dd= self.cleaned_data['dd_savedatapdf']
        )            

class form_dkdethi(forms.Form):
    idcd=forms.CharField(label="Mã công đoạn:")
    cauhoi=forms.IntegerField(label="Câu hỏi:")
    dapan=forms.CharField(label="Đáp án:")

    def save(self):
        rs= detest.objects.filter(idcd=self.cleaned_data['idcd'],cauhoi = self.cleaned_data['cauhoi'])
        if len(rs)==0:  # có the sử dụng if not(rs)
            #rs_s=detest.objects.all()
            rs_s=detest(
                idcd=self.cleaned_data['idcd'],
                cauhoi=self.cleaned_data['cauhoi'],
                ketqua=self.cleaned_data['dapan'],

            )
            rs_s.save()
        else:
            rs.update(
                cauhoi=self.cleaned_data['cauhoi'],
                ketqua=self.cleaned_data['dapan'],
            )


