from django.db import models

# Create your models here.
class baitest(models.Model):
    idcd=models.CharField(max_length=50)
    ten_cd=models.CharField(max_length=50)
    dethi_ad= models.CharField(max_length=200)
    kequa_ad= models.CharField(max_length=200)

class qlnv(models.Model):
    msnv= models.CharField(max_length=50)
    ten=models.CharField(max_length=50)
    username = models.CharField(max_length=50)
    phongban=models.CharField(max_length=50)
    idcd=models.CharField(max_length=50)
    group_id= models.IntegerField(null=True)

class phongban(models.Model):
    maphong=models.CharField(max_length=50)
    tenphong=models.CharField(max_length=50)

class duongdan(models.Model):
    add_name=models.CharField(max_length=50)
    add_dd=models.CharField(max_length=200)
    add_note=models.TextField(max_length=200)

class detest(models.Model):
    idcd=models.CharField(max_length=50)
    cauhoi=models.IntegerField(null=False)
    ketqua=models.CharField(max_length=10)

