# Import các thư viện
from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse, HttpResponseBadRequest
import json
from django.http import JsonResponse
from django.contrib.auth.models import User

from django.http import HttpResponse 
from .forms import registration_form,form_dkdd,form_dkdethi

from django.contrib.auth.decorators import login_required

# Import table dữ liệu
from .models import qlnv, detest

# im port cơ sở dữ liệu sqlite3
import sqlite3   

# import thư viện để sử dụng đường dẫn               
from pathlib import Path

######## Create your views here.

# Định nghĩa đường dẫn cơ sở dũ liệu vào biến BASE_DIR
BASE_DIR = Path(__file__).resolve().parent.parent

# hàm gửi chạy trang home
def index (request): 
    template= loader.get_template('pages/home.html') 
    return HttpResponse(template.render())
    #return render(request,'pages/home.html')  -- cách viết khác của hàm trả về template

# hàm khởi chạy trang login_1

def login_1(request):
    template=loader.get_template('pages/login_1.html')
    #users= User.objects.values_list('username')
    qlnvs= qlnv.objects.filter(username = request.user )
    
    content={
        
        'group_id': qlnvs,
    }
   
    return HttpResponse(template.render(content,request))



# hàm đăng ký user mới

def register(request):  
    form = registration_form()
    f_dkdd= form_dkdd()
    f_dkdethi=form_dkdethi()
    # Đăng ký user
    
    if 'b_dkuser' in request.POST: 
        if request.method == 'POST':
            form = registration_form(request.POST)
            if form.is_valid():
                form.save()
                #return HttpResponseRedirect("/")  di chuyen ve trang home
    
    # Đăng ký đường dẫn   
    if 'b_dkdd' in request.POST:
        if request.method =='POST':
            f_dkdd=form_dkdd(request.POST)
            if f_dkdd.is_valid():
                f_dkdd.save() 
                #return HttpResponseRedirect("/")   di chuyen ve trang home  
                # 
    if 'b_dkdethi' in request.POST:
        if request.method == 'POST':
            f_dkdethi=form_dkdethi(request.POST)
            if f_dkdethi.is_valid():
                f_dkdethi.save()  
           
    return render(request,'pages/register.html',{'form':form ,'f_dkdd':f_dkdd ,'f_dkdethi':f_dkdethi })

@login_required
def postbaitest(request):
    # request.is_ajax() is deprecated since django 3.1
    is_ajax = request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    if is_ajax:
        if request.method == 'GET':
            todos = list(detest.objects.all().values())
            
            return JsonResponse({'context': todos})
        #if request.method == 'POST':
        #    data = json.load(request)
        #    todo = data.get('payload')
        #    Todo.objects.create(task=todo['task'], completed=todo['completed'])
        #    return JsonResponse({'status': 'Todo added!'})
        #return JsonResponse({'status': 'Invalid request'}, status=400)
    else:
        return HttpResponseBadRequest('Invalid request')
        #return render(request,'pages/register.html',{'form':form ,'f_dkdd':f_dkdd ,'f_dkdethi':f_dkdethi })
    
    #if request.is_ajax and request.method == 'POST':
    #    form=form_dkdethi(request.POST)
    #    if form.is_valid():
    #        instance=form.save()
    #        ser_instance=serializers.serialize('json',[instance,])
    #        return JsonResponse({'instance': ser_instance},status=200)
    #    else:
    #        return JsonResponse({'error': form.errors},status=400)
    #return JsonResponse({'error':''},status=400) 


# hàm test xuất dữ liệu lên form dùng sql
def test1(request):
    if request.method == 'POST':
        conection = sqlite3.connect(BASE_DIR/'db.sqlite3')
        rs = conection.cursor()
        sql_comand = ('Select * From qlnv ')
        rs.execute(sql_comand)
        resulft = rs.fetchone()
        content=[]
        content.append({
            'msnv': resulft[0],
            'ten' : resulft[1],
        })

    else:
        content=""
    return render (request,'pages/test1.html',{'content': content})