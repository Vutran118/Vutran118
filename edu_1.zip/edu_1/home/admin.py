from django.contrib import admin
from .models import qlnv,detest

# Register your models here.

@admin.register (qlnv)
    
class qlnv_admin(admin.ModelAdmin):
    list_display=('msnv','ten','phongban')
    search_fields=['msnv']

admin.site.register(detest)